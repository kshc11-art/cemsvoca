# 중국어 학습 v8.6 — 7단계 PWA·실사용 안정화 보고서

## 1. 목표

v8.5의 능력별 FSRS와 중국어 전용 모드를 유지하면서, 실제 배포와 장기 사용에 필요한 PWA 설치, 오프라인 앱 셸, 업데이트 안전성, 데이터 복구, 접근성, 모바일 입력 UX를 보강했다.

## 2. 배포 가능한 PWA 패키지

`cj_v8_phase7_pwa/` 폴더를 그대로 HTTPS 정적 호스팅에 배포할 수 있다.

- `index.html`: 전체 학습 애플리케이션
- `manifest.webmanifest`: 설치 이름, 아이콘, 앱 바로가기
- `sw.js`: 버전 캐시, 오프라인 앱 셸, 네트워크 복구
- `icons/`: 일반·maskable·Apple Touch 아이콘
- `README.md`: 배포 및 로컬 실행 안내

서비스 워커는 새 버전을 자동으로 강제 활성화하지 않는다. 기존 세션 중단을 방지하기 위해 새 워커는 대기하고, 앱의 업데이트 버튼을 눌렀을 때만 `SKIP_WAITING` 메시지로 활성화된다.

## 3. 오프라인·설치 UX

- Android/Chromium `beforeinstallprompt` 설치 버튼
- iOS Safari의 홈 화면 추가 안내
- 설치형 실행 여부 및 서비스 워커 상태 표시
- 온라인·오프라인 상태 배너
- 앱 셸의 navigation fallback
- 이전 캐시 자동 정리
- 학습·중국어 집중·데이터 관리 PWA 바로가기
- 해시 기반 시작 페이지 복원

SheetJS 0.18.5는 기존 CDN 주소를 유지하되 서비스 워커 설치 시 선택적으로 캐시한다. 앱 핵심과 IndexedDB 학습은 오프라인에서 동작하지만, 최초 온라인 실행 전에 완전 오프라인으로 시작하면 Excel 기능은 사용할 수 없다.

## 4. 데이터 안전성

### 체크섬 백업

전체 JSON 백업을 v3 형식으로 변경했다.

- 앱·DB 버전 기록
- 단어·표현·세션·설정 포함
- canonical JSON 기반 SHA-256 체크섬
- 마지막 백업 시각과 7일 경과 알림
- 기존 구형 백업도 복원 가능

### 검증 후 원자적 복원

복원 전 다음을 확인한다.

- JSON 구조와 배열 타입
- 레코드 수 안전 한도
- 단어·표현 필수 키
- v3 백업 체크섬

검증을 통과한 데이터는 `words`, `phrasal_verbs`, `expressions`, `sessions`를 포함하는 하나의 IndexedDB transaction으로 병합한다. 중간 오류가 발생하면 transaction 전체가 중단된다.

### 데이터 무결성 감사

설정의 `데이터 검사`와 `안전 자동수정`에서 다음을 검사한다.

- 음수·NaN 통계
- `correctCount > reviewCount`
- 잘못된 복습 날짜
- stability·difficulty 범위
- 문자열 태그를 배열로 변환
- 누락 Register 기본값
- 잘못된 `skillStates`
- 의미 능력과 기존 최상위 FSRS 필드 동기화

치명적인 필수 키 누락은 자동 삭제하지 않고 보고만 한다.

## 5. 장애 복구와 진단

- 전역 `error` 및 `unhandledrejection` 최근 30건 저장
- 앱 버전, 페이지, 세션 ID와 stack 일부 기록
- 사용자 학습 데이터 본문은 오류 로그에 기록하지 않음
- 저장소 사용량·영구 저장 허용 상태 표시
- 서비스 워커·스토리지·감사 결과·환경 정보를 진단 JSON으로 내보내기
- 기존 공통 세션 체크포인트와 pagehide 복구 유지

## 6. 접근성

- 확대를 막던 `maximum-scale`과 `user-scalable=no` 제거
- 본문 건너뛰기 링크와 main/navigation landmark
- 모달 `role=dialog`, `aria-modal`, 제목 연결
- 모달 열림 시 포커스 이동·Tab 포커스 트랩·닫은 뒤 복귀
- toast와 재출제 배너의 live region
- 비활성 페이지 `inert`와 `aria-hidden`
- 카드형 div의 키보드 Enter/Space 실행
- 1–4 난이도 단축키 및 플래시카드 좌우 탐색
- 명확한 `focus-visible`
- `prefers-reduced-motion`과 고대비 환경 대응
- 입력·텍스트 영역 선택 가능 처리

## 7. 모바일 UX

- Visual Viewport 기반 소프트 키보드 감지
- 키보드가 열리면 하단 내비게이션 숨김
- 입력 포커스 시 화면 중앙으로 스크롤
- 16px 입력 글꼴과 최소 44px 터치 영역
- safe-area 유지
- 선택형 화면 꺼짐 방지 Wake Lock
- 백그라운드 이동 시 Wake Lock 해제, 복귀 시 재요청

## 8. 호환성

- 기존 IndexedDB 이름과 object store를 변경하지 않음
- `skillStates`와 기존 의미 FSRS 동기화 유지
- `commitAnswer()`와 공통 세션 엔진의 평가·재출제 로직 변경 없음
- 기존 JSON 백업 복원 지원
- 단일 HTML도 제공하지만, 설치·오프라인 기능은 PWA 폴더 전체 배포가 필요함

## 9. 검증 결과

총 **82/82 통과**, 실패 0건.

- 브라우저 통합 및 데이터 흐름: 48/48
- 서비스 워커 VM: 10/10
- 정적·문법·자산 검사: 24/24

브라우저 통합 테스트에는 플래시카드, 5지선다와 중국어 전용 6개 모드 시작, 무결성 자동수정, 체크섬 변조 탐지, 원자적 복원, 모달 포커스, inert 페이지와 키보드 가능 컨트롤이 포함된다.

## 10. 검증 한계

관리 환경이 localhost와 file URL 탐색을 차단하므로 실제 origin에서의 서비스 워커 설치·오프라인 reload는 수행하지 못했다. 서비스 워커는 Node VM에서 install, activate, navigation fallback, 정적 캐시, 사용자 승인 업데이트를 실행했고, 브라우저 앱 통합은 비동기 IndexedDB 인터페이스를 재현한 메모리 스텁으로 검증했다.

실제 iOS Safari 및 Android Chrome에서 다음 항목을 최종 확인해야 한다.

- 홈 화면 설치와 아이콘
- OS 강제 종료 후 세션 복구
- 실제 IndexedDB 영구 저장과 저장 공간 회수
- 중국/대만 음성 선택
- 소프트 키보드와 safe-area
- Wake Lock 지원 여부
- 최초 온라인 실행 후 완전 오프라인 Excel 기능
