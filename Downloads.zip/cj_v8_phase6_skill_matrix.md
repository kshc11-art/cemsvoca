# 중국어판 v8.5 능력별 FSRS 매트릭스

| 능력 키 | 연결 모드 | 기존 기록 마이그레이션 | 독립 저장 필드 | 출제 기준 |
|---|---|---|---|---|
| `meaning` | 플래시카드, 뜻/역방향 퀴즈, 빈칸, 연어, 리스닝, 표현 기본 모드 | 기존 카드 FSRS 전체 승계 | `skillStates.meaning` + 기존 최상위 필드 동기화 | 의미 능력의 `nextReview` |
| `pinyin` | 단어 타이핑, 단어 받아쓰기, 병음·성조 입력 | 새 상태로 시작 | `skillStates.pinyin` | 병음 능력의 `nextReview` |
| `tone` | 성조 패턴 | 새 상태로 시작 | `skillStates.tone` | 성조 능력의 `nextReview` |
| `script` | 간체↔번체 | 새 상태로 시작 | `skillStates.script` | 문자 변환 능력의 `nextReview` |
| `measure` | 양사 선택 | 새 상태로 시작 | `skillStates.measure` | 양사 능력의 `nextReview` |
| `sentence` | 단어·표현 예문 배열 | 새 상태로 시작 | `skillStates.sentence` | 어순 능력의 `nextReview` |

## 저장 방식

기존 IndexedDB object store와 keyPath는 변경하지 않습니다. 각 단어·표현 레코드 안에 `skillStates` 객체를 지연 생성합니다. 따라서 기존 JSON/엑셀 백업은 새 필드를 그대로 포함하며, v8.4 이하 데이터도 열 수 있습니다.

## 통계 의미

기존 홈·기본 통계의 `reviewCount`, `stability`, `nextReview`는 `meaning` 능력과 동기화됩니다. 병음·성조 등은 분석 탭의 능력별 대시보드에서 별도로 집계됩니다. 한 능력의 정답은 다른 능력의 복습 간격이나 오답 횟수를 변경하지 않습니다.

## 마이그레이션 한계

과거 버전에서는 뜻 퀴즈와 병음 타이핑이 같은 FSRS 상태에 섞여 있었습니다. 카드별 과거 세션에 능력 구분 로그가 충분하지 않아 이를 정확히 역분해할 수 없습니다. 데이터 손실을 막기 위해 기존 값 전체를 `meaning`으로 보존하고, 나머지 능력은 v8.5부터 새로 측정합니다.
